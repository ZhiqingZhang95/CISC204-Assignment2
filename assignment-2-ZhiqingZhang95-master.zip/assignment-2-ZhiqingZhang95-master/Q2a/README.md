
# Parse tree

Put your parse trees for question 2(a) in this folder.

For the assignment, this is optional. For the quiz, this will be mandatory. So consider this question as optional practice.

If you are unsure about the solutions you produce, and would like to have them examined by a TA, then please specify this in your assignment submission.
