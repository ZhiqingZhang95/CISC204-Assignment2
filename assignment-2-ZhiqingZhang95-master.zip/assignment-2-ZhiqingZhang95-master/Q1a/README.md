
# Truth Tables

Put your truth tables for question 1(a) in this folder.
