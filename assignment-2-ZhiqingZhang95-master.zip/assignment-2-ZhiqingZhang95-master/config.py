

# Replace this file!

from lib204 import wff
P, Q, R, S, T = map(wff.Variable, 'PQRST')
s1 = P
s2 = Q
s3 = R
s4 = S
s5 = T
s6 = P
